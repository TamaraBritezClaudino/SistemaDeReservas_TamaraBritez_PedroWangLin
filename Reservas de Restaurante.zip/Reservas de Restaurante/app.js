/* ============================================================
   SISTEMA DE RESERVAS — app.js
   CRUD: Cargar, Listar, Eliminar
   ============================================================ */

// ----------------------------------------------------------------
// ESTADO GLOBAL
// ----------------------------------------------------------------

let reservas = [
  { id: 1, nombre: "Ana López",     telefono: "+54 11 4567-8901", fecha: "2026-04-22", horario: "20:00", mesa: "3", personas: 4, pedido: "2 menúes sin TACC" },
  { id: 2, nombre: "Carlos Ruiz",   telefono: "+54 11 2345-6789", fecha: "2026-04-22", horario: "13:00", mesa: "1", personas: 2, pedido: "" },
  { id: 3, nombre: "Lucía Herrera", telefono: "+54 11 3456-7890", fecha: "2026-04-23", horario: "21:00", mesa: "5", personas: 6, pedido: "Torta de cumpleaños" }
];

let nextId = 4;
let filtroActual = "todos";

// ----------------------------------------------------------------
// UTILIDADES
// ----------------------------------------------------------------

function getTurno(horario) {
  const h = parseInt(horario.split(":")[0], 10);
  if (h <= 13) return "mañana";
  if (h <= 15) return "tarde";
  return "noche";
}

function getInitials(nombre) {
  return nombre.trim().split(" ").slice(0, 2).map(w => w[0].toUpperCase()).join("");
}

function formatFecha(fechaISO) {
  const [y, m, d] = fechaISO.split("-");
  return `${d}/${m}/${y}`;
}

// ----------------------------------------------------------------
// ESTADÍSTICAS
// ----------------------------------------------------------------

function actualizarStats() {
  const hoy = new Date().toISOString().split("T")[0];
  document.getElementById("stat-total").textContent = reservas.length;
  document.getElementById("stat-hoy").textContent = reservas.filter(r => r.fecha === hoy).length;
  document.getElementById("stat-pedidos").textContent = reservas.filter(r => r.pedido.trim() !== "").length;
}

// ----------------------------------------------------------------
// MENSAJES
// ----------------------------------------------------------------

function mostrarMsg(texto, tipo, msgId = "msg") {
  const el = document.getElementById(msgId);
  el.textContent = texto;
  el.className = `msg ${tipo}`;
  clearTimeout(el._timer);
  el._timer = setTimeout(() => { el.className = "msg hidden"; }, 3500);
}

// ----------------------------------------------------------------
// TABS
// ----------------------------------------------------------------

function switchTab(tabId) {
  document.querySelectorAll(".nav-item").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.tab === tabId);
  });
  document.querySelectorAll(".tab-section").forEach(sec => sec.classList.remove("active"));
  document.getElementById(`tab-${tabId}`).classList.add("active");
  if (tabId === "listar") renderLista();
}

document.querySelectorAll(".nav-item").forEach(btn => {
  btn.addEventListener("click", () => switchTab(btn.dataset.tab));
});

// ----------------------------------------------------------------
// CREATE — Cargar reserva
// ----------------------------------------------------------------

function cargarReserva() {
  const nombre   = document.getElementById("f-nombre").value.trim();
  const telefono = document.getElementById("f-telefono").value.trim();
  const fecha    = document.getElementById("f-fecha").value;
  const horario  = document.getElementById("f-horario").value;
  const mesa     = document.getElementById("f-mesa").value;
  const personas = parseInt(document.getElementById("f-personas").value, 10);
  const pedido   = document.getElementById("f-pedido").value.trim();

  if (!nombre || !fecha || !horario || !mesa || !personas) {
    mostrarMsg("Completá todos los campos obligatorios (*) antes de guardar.", "error");
    return;
  }

  if (personas < 1 || personas > 8) {
    mostrarMsg("La cantidad de personas debe ser entre 1 y 8.", "error");
    return;
  }

  const duplicado = reservas.find(
    r => r.fecha === fecha && r.horario === horario && r.mesa === mesa
  );
  if (duplicado) {
    mostrarMsg(`La Mesa ${mesa} ya está reservada el ${formatFecha(fecha)} a las ${horario} hs.`, "error");
    return;
  }

  reservas.push({ id: nextId++, nombre, telefono, fecha, horario, mesa, personas, pedido });
  actualizarStats();
  limpiarForm();
  mostrarMsg(`Reserva para "${nombre}" registrada correctamente.`, "success");
}

function limpiarForm() {
  ["f-nombre","f-telefono","f-fecha","f-horario","f-mesa","f-personas","f-pedido"]
    .forEach(id => (document.getElementById(id).value = ""));
  document.getElementById("f-fecha").value = new Date().toISOString().split("T")[0];
}

// ----------------------------------------------------------------
// READ — Listar reservas
// ----------------------------------------------------------------

function renderLista() {
  const query = (document.getElementById("search-input").value || "").toLowerCase();

  let lista = reservas.slice();

  if (filtroActual !== "todos") {
    lista = lista.filter(r => getTurno(r.horario) === filtroActual);
  }

  if (query) {
    lista = lista.filter(r =>
      r.nombre.toLowerCase().includes(query) || `mesa ${r.mesa}`.includes(query)
    );
  }

  lista.sort((a, b) => (a.fecha + a.horario).localeCompare(b.fecha + b.horario));

  const container = document.getElementById("reservas-list");

  if (lista.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🍽</div>
        <p>No se encontraron reservas.</p>
      </div>`;
    return;
  }

  container.innerHTML = lista.map(r => {
    const turno = getTurno(r.horario);
    const badgeClass = turno === "mañana" ? "badge-manana" : turno === "tarde" ? "badge-tarde" : "badge-noche";
    const pedidoStr  = r.pedido   ? ` · 🍽 ${r.pedido}`   : "";
    const telStr     = r.telefono ? ` · ${r.telefono}` : "";
    return `
      <div class="reserva-card" id="reserva-${r.id}">
        <div class="avatar">${getInitials(r.nombre)}</div>
        <div class="res-info">
          <div class="res-nombre">${r.nombre}</div>
          <div class="res-detalle">
            ${formatFecha(r.fecha)} · ${r.horario} hs · Mesa ${r.mesa} · ${r.personas} persona${r.personas !== 1 ? "s" : ""}${telStr}${pedidoStr}
          </div>
        </div>
        <div class="res-meta">
          <span class="badge ${badgeClass}">${turno}</span>
          <button class="btn btn-danger" onclick="eliminarReserva(${r.id})">Eliminar</button>
        </div>
      </div>`;
  }).join("");
}

// ----------------------------------------------------------------
// DELETE — Eliminar reserva
// ----------------------------------------------------------------

function eliminarReserva(id) {
  const reserva = reservas.find(r => r.id === id);
  if (!reserva) return;
  reservas = reservas.filter(r => r.id !== id);
  actualizarStats();
  renderLista();
  mostrarMsg(`Reserva de "${reserva.nombre}" eliminada.`, "success", "msg2");
}

// ----------------------------------------------------------------
// FILTRO
// ----------------------------------------------------------------

function setFiltro(filtro, el) {
  filtroActual = filtro;
  document.querySelectorAll(".pill").forEach(p => p.classList.remove("active"));
  el.classList.add("active");
  renderLista();
}

// ----------------------------------------------------------------
// INIT
// ----------------------------------------------------------------

document.getElementById("f-fecha").value = new Date().toISOString().split("T")[0];
actualizarStats();

window.cargarReserva   = cargarReserva;
window.limpiarForm     = limpiarForm;
window.eliminarReserva = eliminarReserva;
window.renderLista     = renderLista;
window.setFiltro       = setFiltro;